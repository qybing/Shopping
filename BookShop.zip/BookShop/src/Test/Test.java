package Test;

import java.util.List;

import com.oracle.book.biz.BookBiz;
import com.oracle.book.biz.impl.BookBizImpl;
import com.oracle.book.entity.Book;

public class Test {
	public static void main(String[] args) {
		BookBiz bookBiz = new BookBizImpl();
		try{
		Book book = new Book();
		book.setBname("��");
		
		List<Book> bookList = bookBiz.findBookByPage(1, book);
		System.out.println(bookList.size());
		int pages = bookBiz.findBooksPages(book);
		System.out.println("pages:"+pages);

		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
