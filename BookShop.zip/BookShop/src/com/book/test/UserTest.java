package com.book.test;

import java.util.ArrayList;
import java.util.List;

import com.oracle.book.biz.AddressBiz;
import com.oracle.book.biz.CommentBiz;
import com.oracle.book.biz.TypeBiz;
import com.oracle.book.biz.Userbiz;
import com.oracle.book.biz.impl.AddressBizImpl;
import com.oracle.book.biz.impl.CommentBizImpl;
import com.oracle.book.biz.impl.TypeBizImpl;
import com.oracle.book.biz.impl.UserBizImpl;
import com.oracle.book.entity.Address;
import com.oracle.book.entity.Comment;
import com.oracle.book.entity.Type;
import com.oracle.book.entity.User;

public class UserTest {
	private static Userbiz userBiz = new UserBizImpl();
	private static TypeBiz typeBiz = new TypeBizImpl();
	private static CommentBiz comBiz = new CommentBizImpl();
	private static AddressBiz addressBiz = new AddressBizImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
//			findUser();
//			findTypes();
//			findComment();
//			addComment();
//			findAddressByUid();
			addUser();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public static void findUser() throws Exception{
		User user = userBiz.findUser("zhangsan", "123456");
		if(user != null)
			System.out.println(user.getUid()+"\t"+user.getUname());
		else
			System.out.println("未找到此用户");
	}
	
	public static void findTypes() throws Exception{
		List<Type> typeList = typeBiz.findTypes();
		for(Type type : typeList){
			System.out.println(type.getTypeName());
		}
	}
	
	public static void findComment() throws Exception{
		List<Comment> comList = comBiz.findCommentsByBid(1);
		for(Comment c: comList)
			System.out.println(c.getCname());
	}
	
	public static void addComment() throws Exception{
		String uname = "zhangsan";
		String upwd = "123456";
		User user = userBiz.findUser(uname, upwd);
		
		int bid = 2;
		int score = 4;
		String content = "这本书真好看，为什么会有这么好看的书";
		Comment comment = new Comment();		
		comment.setBid(bid);
		comment.setBscore(score);
		comment.setCname(content);
		comment.setUid(user.getUid());
		int num = comBiz.addComment(comment, user);
		System.out.println(num);
		
	}
	public static void findAddressByUid() throws Exception{
		List<Address> addressList = addressBiz.findAddressByUid(1);
		for(Address addr : addressList){
			System.out.println(addr.getAddress());
		}
	}
	
	public static void addUser() throws Exception{
		String uname = "吴亦凡";
		String upass = "123456";
		User user = new User();
		user.setUname(uname);
		user.setUpass(upass);
		System.out.println(userBiz.addUser(user));
	}
}
