package com.oracle.book.entity;

import java.io.Serializable;
import java.util.Date;

import com.oracle.book.util.DateUtil;

public class OrderDetail implements Serializable {
	private Integer odid;
	private Integer oid;
	private Integer bid;
	private Integer total;
	private Date odate;
	public Integer getOdid() {
		return odid;
	}
	public void setOdid(Integer odid) {
		this.odid = odid;
	}
	public Integer getOid() {
		return oid;
	}
	public void setOid(Integer oid) {
		this.oid = oid;
	}
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public String getOdate() throws Exception {
		if(odate==null)
			return "";
		return DateUtil.toString(odate);
	}
	public void setOdate(Date odate) {
		this.odate = odate;
	}
	
}
