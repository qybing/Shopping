package com.oracle.book.entity;

import java.io.Serializable;

public class Car implements Serializable{
	private Book book;
	private Integer number;
	
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	
}
