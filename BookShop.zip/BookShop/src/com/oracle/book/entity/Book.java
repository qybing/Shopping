package com.oracle.book.entity;

import java.io.Serializable;

public class Book implements Serializable {
	private Integer bid;
	private String bname; 
	private String bcontent;
	private Integer bprice;
	private String bimage;
	private Integer bnumber;
	private Integer typeid;
	
	// 添加一些查询的条件
	private Integer minPrice;
	private Integer maxPrice;
	
	
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public Integer getBprice() {
		return bprice;
	}
	public void setBprice(Integer bprice) {
		this.bprice = bprice;
	}
	public String getBimage() {
		return bimage;
	}
	public void setBimage(String bimage) {
		this.bimage = bimage;
	}
	public Integer getBnumber() {
		return bnumber;
	}
	public void setBnumber(Integer bnumber) {
		this.bnumber = bnumber;
	}
	public Integer getTypeid() {
		return typeid;
	}
	public void setTypeid(Integer typeid) {
		this.typeid = typeid;
	}
	public Integer getMinPrice() {
		return minPrice;
	}
	public void setMinPrice(Integer minPrice) {
		this.minPrice = minPrice;
	}
	public Integer getMaxPrice() {
		return maxPrice;
	}
	public void setMaxPrice(Integer maxPrice) {
		this.maxPrice = maxPrice;
	}

	
}
