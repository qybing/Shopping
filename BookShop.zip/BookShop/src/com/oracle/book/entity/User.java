package com.oracle.book.entity;

import java.io.Serializable;

public class User implements Serializable {
	private Integer uid;
	private String uname;
	private String upass;
	private Integer ulevel;
	private Integer uscore;
	private Integer ustatus;
	
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public Integer getUlevel() {
		return ulevel;
	}
	public void setUlevel(Integer ulevel) {
		this.ulevel = ulevel;
	}
	public Integer getUscore() {
		return uscore;
	}
	public void setUscore(Integer uscore) {
		this.uscore = uscore;
	}
	public Integer getUstatus() {
		return ustatus;
	}
	public void setUstatus(Integer ustatus) {
		ustatus = ustatus;
	}
}
