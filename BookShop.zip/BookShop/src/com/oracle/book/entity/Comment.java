package com.oracle.book.entity;

import java.io.Serializable;
import java.util.Date;

import com.oracle.book.util.DateUtil;

public class Comment implements Serializable {
	private Integer cid;
	private String cname;
	private Integer uid;
	private Integer bid;
	private Integer bscore;
	private Date cdate;
	
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public Integer getBscore() {
		return bscore;
	}
	public void setBscore(Integer bscore) {
		this.bscore = bscore;
	}
	public String getCdate() throws Exception {
		if(cdate==null)
			return "";
		return DateUtil.toString(cdate);
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}
	
	
}
