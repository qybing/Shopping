package com.oracle.book.entity;

import java.io.Serializable;
import java.util.Date;

import com.oracle.book.util.DateUtil;

public class OrderInfo implements Serializable{
	private Integer oid;
	private Integer uid;
	private Integer total;
	private String address;
	private String beizhu;
	private String status;
	private Date odate;
	public Integer getOid() {
		return oid;
	}
	public void setOid(Integer oid) {
		this.oid = oid;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOdate() throws Exception {
		if(odate==null)
			return "";
		return DateUtil.toString(odate);
	}
	public void setOdate(Date odate) {
		this.odate = odate;
	}
	
	
}
