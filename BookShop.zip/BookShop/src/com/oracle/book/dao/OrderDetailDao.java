package com.oracle.book.dao;

import com.oracle.book.entity.OrderDetail;

public interface OrderDetailDao {
	// ���Ӷ�����ϸ
	public int addOrderDetail(OrderDetail detail) throws Exception;
}
