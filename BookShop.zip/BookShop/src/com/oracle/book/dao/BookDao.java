package com.oracle.book.dao;

import java.util.List;

import com.oracle.book.entity.Book;

public interface BookDao {
	// 根据已有的条件，查询一共有多少页
	public int findBooksPages(Book book) throws Exception;
	
	// 根据页数和条件，查询本页的数据
	public List<Book> findBookByPage(int page, Book book) throws Exception;
	
	// 根据图书id，查询单本图书的功能
	public Book findBookById(int bid) throws Exception;
	
	// 更新图书的方法
	public int updateBook(Book book) throws Exception;
}
