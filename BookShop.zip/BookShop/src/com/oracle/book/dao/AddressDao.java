package com.oracle.book.dao;

import java.util.List;

import com.oracle.book.entity.Address;

public interface AddressDao {
	public List<Address> findAddressByUid(Integer Uid) throws Exception;

	public int addAddress(Address address) throws Exception;
}
