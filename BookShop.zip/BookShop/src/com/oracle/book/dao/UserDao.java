package com.oracle.book.dao;

import com.oracle.book.entity.User;

public interface UserDao {
	// 增加新用户
	public int addUser(User user) throws Exception;
	
	// 根据用户名和密码，查询用户的方法
	public User findUser(String uname, String upass) throws Exception;
	
	// 修改用户积分
	public int updateUser(User user) throws Exception;
	
}
