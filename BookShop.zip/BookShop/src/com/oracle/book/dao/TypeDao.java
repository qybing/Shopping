package com.oracle.book.dao;

import java.util.List;

import com.oracle.book.entity.*;

public interface TypeDao {
	public List<Type> findTypes() throws Exception;
	
	public List<Type> findTypeBySql(String sqlStr, Object[] obj) throws Exception;
}
