package com.oracle.book.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.oracle.book.dao.OrderDao;
import com.oracle.book.entity.OrderInfo;
import com.oracle.book.util.DbUtil;

public class OrderDaoImpl implements OrderDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rst;
	
	
	@Override
	public int addOrder(OrderInfo order) throws Exception {
		String sqlStr = "insert into order_info values(oi_sql.nextval,?,?,?,?,,?sysdate)";
		return DbUtil.executeUpdate(sqlStr, new Object[]{order.getUid(),order.getTotal(),order.getAddress(),order.getBeizhu(),order.getStatus()});
	}

	@Override
	public int findOrderIdByUid(Integer uid) throws Exception {
		int num = -1;
		conn = DbUtil.createConnection();
		String sqlStr = "select max(o_id) as o_id from order_info where u_id = ?";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, uid);
		rst = pstmt.executeQuery();
		if(rst.next()){
			num = rst.getInt("o_id");
		}
		return num;
	}

}
