package com.oracle.book.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.oracle.book.dao.CommentDao;
import com.oracle.book.entity.Comment;
import com.oracle.book.util.DbUtil;

public class CommentDaoImpl implements CommentDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rst;
	
	
	// ��������
	public int addComment(Comment comment) throws Exception{
		String sqlStr = "insert into book_comment(c_id,c_name,u_id,b_id,b_score,c_date) values (comment_seq.nextval,?,?,?,?,sysdate)";
		return DbUtil.executeUpdate(sqlStr, new Object[]{comment.getCname(),comment.getUid(),comment.getBid(),comment.getBscore()});
	}
		
	// ��֤�����Ƿ���Է�������
	public Comment findComment(int uid, int bid) throws Exception{
		Comment com = null;
		conn = DbUtil.createConnection();
		String sqlStr = "select * from book_comment "
				+ "where b_id = ? and u_id = ? and"
				+ " to_char(c_date,'yyyy-MM-dd') = to_char(sysdate,'yyyy-MM-dd')";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, bid);
		pstmt.setInt(2, uid);
		rst = pstmt.executeQuery();
		if(rst.next()){
			com = new Comment();
			com.setBid(rst.getInt("b_id"));
			com.setBscore(rst.getInt("b_score"));
			com.setCdate(rst.getDate("c_date"));
			com.setCid(rst.getInt("c_id"));
			com.setCname(rst.getString("c_name"));
			com.setUid(rst.getInt("u_id"));
		}
		return com;
	}
		
		
	@Override
	public List<Comment> findCommentsByBid(int bid) throws Exception {
		List<Comment> comList = new ArrayList<>();
		conn = DbUtil.createConnection();
		String sqlStr = "select * from book_comment where b_id = ? order by c_id";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, bid);
		rst = pstmt.executeQuery();
		while(rst.next()){
			Comment com = new Comment();
			com.setBid(rst.getInt("b_id"));
			com.setBscore(rst.getInt("b_score"));
			com.setCdate(rst.getDate("c_date"));
			com.setCid(rst.getInt("c_id"));
			com.setCname(rst.getString("c_name"));
			com.setUid(rst.getInt("u_id"));
			comList.add(com);
		}
		return comList;
	}
	
}
