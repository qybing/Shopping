package com.oracle.book.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.oracle.book.dao.BookDao;
import com.oracle.book.entity.Book;
import com.oracle.book.util.DbUtil;

public class BookDaoImpl implements BookDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rst;
	

	@Override
	public int findBooksPages(Book book) throws Exception {
		conn = DbUtil.createConnection();
		
		String sqlStr ="select count(1) as ts from book_info where 1=1";
		if(book!=null){
			if(book.getBname()!=null && !"".equals(book.getBname()))
				sqlStr += " and b_name like '%"+book.getBname()+"%'";
			if(book.getBcontent()!=null && !"".equals(book.getBcontent()))
				sqlStr += " and b_content like '%"+book.getBcontent()+"%'";
			if(book.getMaxPrice()!=null)
				sqlStr += " and b_price <= "+book.getMaxPrice();
			if(book.getMinPrice()!=null)
				sqlStr += " and b_price >= "+book.getMinPrice();
			if(book.getTypeid()!=null)
				sqlStr += " and type_id = "+book.getTypeid();
		}
		pstmt = conn.prepareStatement(sqlStr);
		rst = pstmt.executeQuery();
		rst.next();
		int rows = rst.getInt("ts");
		if(rows%4==0)
			return rows/4;
		return rows/4+1;
	}

	@Override
	public List<Book> findBookByPage(int page, Book book) throws Exception {
		List<Book> bookList = new ArrayList<>();
		
		conn = DbUtil.createConnection();
		String sqlStr = "select b_id,b_name,b_content,b_price,b_image,b_number,type_id from"+
				" (select rownum as ts,b.* from book_info b where rownum <= "+page+"*3";
		if(book!=null){
			if(book.getBname()!=null && !"".equals(book.getBname()))
				sqlStr += " and b_name like '%"+book.getBname()+"%'";
			if(book.getBcontent()!=null && !"".equals(book.getBcontent()))
				sqlStr += " and b_content like '%"+book.getBcontent()+"%'";
			if(book.getMaxPrice()!=null)
				sqlStr += " and b_price <= "+book.getMaxPrice();
			if(book.getMinPrice()!=null)
				sqlStr += " and b_price >= "+book.getMinPrice();
			if(book.getTypeid()!=null)
				sqlStr += " and type_id = "+book.getTypeid();
		}		
		sqlStr += "  order by b_id) temp where ts > ("+page+"-1) * 3";
		pstmt = conn.prepareStatement(sqlStr);
		rst = pstmt.executeQuery();
		while(rst.next()){
			Book tbook = new Book();
			tbook.setBcontent(rst.getString("b_content"));
			tbook.setBid(rst.getInt("b_id"));
			tbook.setBimage(rst.getString("b_image"));
			tbook.setBname(rst.getString("b_name"));
			tbook.setBnumber(rst.getInt("b_number"));
			tbook.setBprice(rst.getInt("b_price"));
			tbook.setTypeid(rst.getInt("type_id"));
			bookList.add(tbook);
		}
		return bookList;
	}
	
	public Book findBookById(int bid) throws Exception{
		Book book = null;
		conn = DbUtil.createConnection();
		String sqlStr = "select * from book_info where b_id = ?";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, bid);
		rst = pstmt.executeQuery();
		if(rst.next()){
			book = new Book();
			book.setBcontent(rst.getString("b_content"));
			book.setBid(rst.getInt("b_id"));
			book.setBimage(rst.getString("b_image"));
			book.setBname(rst.getString("b_name"));
			book.setBnumber(rst.getInt("b_number"));
			book.setBprice(rst.getInt("b_price"));
			book.setTypeid(rst.getInt("type_id"));
		}
		return book;
	}

	@Override
	public int updateBook(Book book) throws Exception {
		String sqlStr = "update book_info set b_name = ? and b_content = ? and b_price = ? and b_image = ? and b_number = ? and type_id = ? where b_id = ?";
		return DbUtil.executeUpdate(sqlStr, new Object[]{book.getBname(),book.getBcontent(),book.getBprice(),book.getBimage(),book.getBnumber(),book.getTypeid(),book.getBid()});
	}
	
}
