package com.oracle.book.dao.impl;

import com.oracle.book.dao.OrderDetailDao;
import com.oracle.book.entity.OrderDetail;
import com.oracle.book.util.DbUtil;

public class OrderDetailDaoImpl implements OrderDetailDao {

	@Override
	public int addOrderDetail(OrderDetail detail) throws Exception {
		String sqlStr = "insert into order_detail values (od_seq.nextval,?,?,?,sysdate)";
		return DbUtil.executeUpdate(sqlStr, new Object[]{detail.getOid(),detail.getBid(),detail.getTotal()});
	}

}
