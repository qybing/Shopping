package com.oracle.book.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.oracle.book.dao.TypeDao;
import com.oracle.book.entity.Type;
import com.oracle.book.util.DbUtil;

public class TypeDaoImpl implements TypeDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rst;
	
	@Override
	public List<Type> findTypes() throws Exception {
		String sqlStr = "select type_id,type_name from book_type";
		return findTypeBySql(sqlStr,null);
	}

	@Override
	public List<Type> findTypeBySql(String sqlStr, Object[] objs) throws Exception {
		List<Type> typeList = new ArrayList<>();
		conn = DbUtil.createConnection();
		pstmt = conn.prepareStatement(sqlStr);
		if(objs!=null){
			for(int i = 0; i < objs.length; i++)
				pstmt.setObject(i+1, objs[i]);
		}
		rst = pstmt.executeQuery();
		while(rst.next()){
			Type type = new Type();
			type.setTypeId(rst.getInt("type_id"));
			type.setTypeName(rst.getString("type_name"));
			typeList.add(type);
		}
		return typeList;
	}

}
