package com.oracle.book.dao.impl;

import com.oracle.book.entity.User;
import com.oracle.book.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.oracle.book.dao.UserDao;

public class UserDaoImpl implements UserDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rst;
	
	
	@Override
	public User findUser(String uname, String upass) throws Exception {
		User user = null;
		conn = DbUtil.createConnection();
		String sqlStr = "select u_id,u_name,u_pass,u_status,u_level,u_score from users where u_name = ? and u_pass = ?";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setString(1, uname);
		pstmt.setString(2, upass);
		rst = pstmt.executeQuery();
		if(rst.next()){
			user = new User();
			user.setUid(rst.getInt("u_id"));
			user.setUname(rst.getString("u_name"));
			user.setUpass(rst.getString("u_pass"));
			user.setUstatus(rst.getInt("u_status"));
			user.setUlevel(rst.getInt("u_level"));
			user.setUscore(rst.getInt("u_score"));
		}
		DbUtil.close(conn, pstmt, rst);
		return user;
	}


	@Override
	public int updateUser(User user) throws Exception {
		String sqlStr = "update users set u_name = ?, u_pass = ?, u_status = ?, ulevel = ? , u_score = ? where u_id = ?";
		return DbUtil.executeUpdate(sqlStr, new Object[]{user.getUname(),user.getUpass(),user.getUstatus(),user.getUlevel(),user.getUscore(),user.getUid()});
	}


	@Override
	public int addUser(User user) throws Exception {
		String sqlStr = "insert into users(u_id,u_name,u_pass,u_status,u_level,u_score) values (users_seq.nextval,?,?,0,0,0)";
		return DbUtil.executeUpdate(sqlStr, new Object[]{user.getUname(),user.getUpass()});
	}

	
}
