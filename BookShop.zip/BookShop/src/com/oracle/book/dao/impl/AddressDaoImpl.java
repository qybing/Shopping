package com.oracle.book.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.oracle.book.dao.AddressDao;
import com.oracle.book.entity.Address;
import com.oracle.book.util.DbUtil;

public class AddressDaoImpl implements AddressDao {
	private Connection conn ;
	private PreparedStatement pstmt;
	private ResultSet rst;
	
	@Override
	public List<Address> findAddressByUid(Integer uid) throws Exception {
		List<Address> addressList = new ArrayList<Address>();
		conn = DbUtil.createConnection();
		String sqlStr = "select * from address where u_id = ?";
		pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, uid);
		rst = pstmt.executeQuery();
		while(rst.next()){
			Address address = new Address();
			address.setAid(rst.getInt("a_id"));
			address.setUid(rst.getInt("u_id"));
			address.setAddress(rst.getString("address"));
			addressList.add(address);
		}
		return addressList;
	}

	@Override
	public int addAddress(Address address) throws Exception {
		String sqlStr = "insert into address values (address_seq.nextval,?,?)";
		return DbUtil.executeUpdate(sqlStr, new Object[]{address.getUid(),address.getAddress()});
	}

}
