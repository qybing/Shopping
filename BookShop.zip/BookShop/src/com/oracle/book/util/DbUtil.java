package com.oracle.book.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class DbUtil {
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	// 创建连接对象
	private static Connection conn = null;
	public static Connection createConnection() throws Exception{
		if(conn == null || conn.isClosed())
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","haha","123456");
		return conn;
	}
	
	// 关闭数据库
	public static void close(Connection conn, Statement stmt, ResultSet rst) throws Exception{
		if(rst != null)
			rst.close();
		if(stmt != null)
			stmt.close();
		if(conn != null)
			conn.close();
	}
	public static void close(Connection conn, Statement stmt) throws Exception{
		if(stmt != null)
			stmt.close();
		if(conn != null)
			conn.close();
	}
	public static void close(Connection conn) throws Exception{
		if(conn != null)
			conn.close();
	}
	
	// 进行增删改查的操作
	public static int executeUpdate(String sqlStr, Object...objs) throws Exception{
		int num = -1;
		Connection conn = createConnection();
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		if(objs!=null){
			for(int i = 0; i < objs.length; i++){
				pstmt.setObject(i+1, objs[i]);
			}
		}
		num = pstmt.executeUpdate();
		return num;
	}
	
}
