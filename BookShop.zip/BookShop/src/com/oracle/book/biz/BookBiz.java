package com.oracle.book.biz;

import java.util.List;

import com.oracle.book.entity.Book;

public interface BookBiz {
	public int findBooksPages(Book book) throws Exception;
	
	public List<Book> findBookByPage(int page, Book book) throws Exception;
	
	// ����ͼ���ID ��ѯͼ�����ϸ
	public Book findBookById(int bid) throws Exception;
}
