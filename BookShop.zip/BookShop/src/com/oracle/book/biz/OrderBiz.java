package com.oracle.book.biz;

import java.util.List;

import com.oracle.book.entity.OrderDetail;
import com.oracle.book.entity.OrderInfo;

public interface OrderBiz {
	public int addOrderInfo(OrderInfo order,List<OrderDetail> detaiList) throws Exception;
}
