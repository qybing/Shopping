package com.oracle.book.biz.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.oracle.book.biz.BookBiz;
import com.oracle.book.dao.BookDao;
import com.oracle.book.dao.impl.BookDaoImpl;
import com.oracle.book.entity.Book;
import com.oracle.book.util.DbUtil;

public class BookBizImpl implements BookBiz {
	private BookDao bookDao = new BookDaoImpl();
	@Override
	public int findBooksPages(Book book) throws Exception {
		Connection conn = DbUtil.createConnection();
		int num = bookDao.findBooksPages(book);
		DbUtil.close(conn);
		return num;
	}

	@Override
	public List<Book> findBookByPage(int page, Book book) throws Exception {
		List<Book> bookList = new ArrayList<>();
		Connection conn = DbUtil.createConnection();
		bookList = bookDao.findBookByPage(page, book);
		DbUtil.close(conn);
		return bookList;
	}
	
	public Book findBookById(int bid) throws Exception{
		Connection conn = DbUtil.createConnection();
		Book book = bookDao.findBookById(bid);
		DbUtil.close(conn);
		return book;
	}

}
