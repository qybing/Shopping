package com.oracle.book.biz.impl;

import java.sql.Connection;
import java.util.List;

import com.oracle.book.biz.TypeBiz;
import com.oracle.book.dao.TypeDao;
import com.oracle.book.dao.impl.TypeDaoImpl;
import com.oracle.book.entity.Type;
import com.oracle.book.util.DbUtil;

public class TypeBizImpl implements TypeBiz {
	private TypeDao typeDao = new TypeDaoImpl();
	
	@Override
	public List<Type> findTypes() throws Exception {
		Connection conn = DbUtil.createConnection();
		List<Type> typeList= typeDao.findTypes();
		DbUtil.close(conn);
		return typeList;
	}

}
