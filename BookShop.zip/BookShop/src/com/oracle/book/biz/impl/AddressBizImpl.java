package com.oracle.book.biz.impl;

import java.sql.Connection;
import java.util.List;

import com.oracle.book.biz.AddressBiz;
import com.oracle.book.dao.AddressDao;
import com.oracle.book.dao.impl.AddressDaoImpl;
import com.oracle.book.entity.Address;
import com.oracle.book.util.DbUtil;

public class AddressBizImpl implements AddressBiz {
	private AddressDao addressDao = new AddressDaoImpl();
	
	@Override
	public List<Address> findAddressByUid(Integer uid) throws Exception {
		Connection conn = DbUtil.createConnection();
		List<Address> addressList = addressDao.findAddressByUid(uid);
		DbUtil.close(conn);
		return addressList;
	}

	@Override
	public int addAddress(Address address) throws Exception {
		Connection conn = DbUtil.createConnection();
		int num = addressDao.addAddress(address);
		DbUtil.close(conn);
		return num;
	}

}
