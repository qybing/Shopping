package com.oracle.book.biz.impl;

import java.sql.Connection;
import java.util.List;

import com.oracle.book.biz.CommentBiz;
import com.oracle.book.dao.CommentDao;
import com.oracle.book.dao.UserDao;
import com.oracle.book.dao.impl.CommentDaoImpl;
import com.oracle.book.dao.impl.UserDaoImpl;
import com.oracle.book.entity.Comment;
import com.oracle.book.entity.User;
import com.oracle.book.util.DbUtil;

public class CommentBizImpl implements CommentBiz {
	private CommentDao comDao = new CommentDaoImpl();
	private UserDao userDao = new UserDaoImpl();
	@Override
	public List<Comment> findCommentsByBid(int bid) throws Exception {
		Connection conn = DbUtil.createConnection();
		List<Comment> comList = comDao.findCommentsByBid(bid);
		DbUtil.close(conn);
		return comList;
	}

	@Override
	public int addComment(Comment comment, User user) throws Exception {
		Connection conn = DbUtil.createConnection();
		try{
			conn.setAutoCommit(false);
			Comment checkComment = comDao.findComment(user.getUid(), comment.getBid());
			if(checkComment!=null)
				return -1;
			
			user.setUscore(user.getUscore()+2);
			userDao.updateUser(user);
			comDao.addComment(comment);
			conn.commit();
		}catch(Exception e){
			e.printStackTrace();
			conn.rollback();
			return 0;
		}
		DbUtil.close(conn);
		return 1;
	}


}
