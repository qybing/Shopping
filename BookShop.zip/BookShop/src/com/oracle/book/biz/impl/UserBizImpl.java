package com.oracle.book.biz.impl;

import java.sql.Connection;

import com.oracle.book.biz.Userbiz;
import com.oracle.book.dao.UserDao;
import com.oracle.book.dao.impl.UserDaoImpl;
import com.oracle.book.entity.User;
import com.oracle.book.util.DbUtil;

public class UserBizImpl implements Userbiz {
	private UserDao userDao = new UserDaoImpl();
	
	@Override
	public User findUser(String uname, String upass) throws Exception {
		User user = null;
		Connection conn = DbUtil.createConnection();
		user = userDao.findUser(uname, upass);
		DbUtil.close(conn);
		return user;
	}

	@Override
	public int addUser(User user) throws Exception {
		int num = -1;
		Connection conn = DbUtil.createConnection();
		User checkUser = userDao.findUser(user.getUname(), user.getUpass());
		if(checkUser!=null)
			return num;
		else{
			num = userDao.addUser(user);
		}
		DbUtil.close(conn);
		return num;
	}

}
