package com.oracle.book.biz;

import java.util.List;

import com.oracle.book.entity.Type;

public interface TypeBiz {
	public List<Type> findTypes() throws Exception;
}
