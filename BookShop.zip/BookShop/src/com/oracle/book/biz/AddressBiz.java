package com.oracle.book.biz;

import java.util.List;

import com.oracle.book.entity.Address;

public interface AddressBiz {
	public List<Address> findAddressByUid(Integer Uid) throws Exception;
	
	public int addAddress(Address address) throws Exception;
}
