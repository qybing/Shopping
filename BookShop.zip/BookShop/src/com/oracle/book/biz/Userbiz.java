package com.oracle.book.biz;

import com.oracle.book.entity.User;

public interface Userbiz {
	// 根据用户名和密码，查询用户的方法
	public User findUser(String uname, String upass) throws Exception;
	
	public int addUser(User user) throws Exception;
}
