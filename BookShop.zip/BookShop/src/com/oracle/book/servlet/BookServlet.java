package com.oracle.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oracle.book.biz.impl.AddressBizImpl;
import com.oracle.book.entity.Address;
import com.oracle.book.entity.User;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/bookServlet")
public class BookServlet extends HttpServlet {
	private AddressBizImpl addressBiz = new AddressBizImpl(); 
	
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			request.setCharacterEncoding("utf-8");
			String type = request.getParameter("type");
			if("pay".equals(type)){
				pay(request,response);
				return;
			}
		}catch(Exception e){
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		}
	}
	
	public void pay(HttpServletRequest request, HttpServletResponse response) throws Exception{
		// ��ȡ����
		HttpSession session = request.getSession();
		String bids[] = request.getParameterValues("bid");
		String total = request.getParameter("total");
		String addAddress = request.getParameter("addAddress");
		String beizhu = request.getParameter("beizhu");
		User user = (User)session.getAttribute("user");
		String addressStr = "";
		if("new".equals(addAddress)){
			addressStr = request.getParameter("newaddress");
			Address address = new Address();
			address.setUid(user.getUid());
			address.setAddress(addressStr);
			addressBiz.addAddress(address);
		}else{
			addressStr = request.getParameter("rdoAddress");
		}
		// ʵ�ֽ���ľ���ҵ��
		
	}
	
	

}
