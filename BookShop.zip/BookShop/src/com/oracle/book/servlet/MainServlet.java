package com.oracle.book.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oracle.book.biz.impl.BookBizImpl;
import com.oracle.book.biz.impl.TypeBizImpl;
import com.oracle.book.entity.Book;
import com.oracle.book.entity.Type;

public class MainServlet extends HttpServlet {
	// ����ҵ�񷽷�
	private BookBizImpl bookBiz = new BookBizImpl();
	private TypeBizImpl typeBiz = new TypeBizImpl();
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			// ���ñ����ʽ
			request.setCharacterEncoding("utf-8");
			
	
			// ��ȡ����Ĳ���
			int nowPage = 1;
			if(request.getParameter("nowPage")!=null)
				nowPage = Integer.parseInt(request.getParameter("nowPage"));
			Book book = new Book();
			String typeId = request.getParameter("typeId");
			String bname = request.getParameter("bname");
			String bcontent = request.getParameter("bcontent");
			String minprice = request.getParameter("minprice");
			String maxprice = request.getParameter("maxprice");
			
			if(typeId!=null && !typeId.equals("-1"))
				book.setTypeid(Integer.parseInt(typeId));
			if(bname!=null && !bname.equals(""))
				book.setBname(bname);
			if(bcontent!=null && !bcontent.equals(""))
				book.setBcontent(bcontent);
			if(minprice!=null && !minprice.equals(""))
				book.setMinPrice(Integer.parseInt(minprice));
			if(maxprice!=null && !maxprice.equals(""))
				book.setMaxPrice(Integer.parseInt(maxprice));
			
			
			
			
			List<Book> bookList = bookBiz.findBookByPage(nowPage, book);
			List<Type> typeList = typeBiz.findTypes();
			
			int pages = bookBiz.findBooksPages(book);
			
			// �������ݣ���תҳ��
			
			request.setAttribute("typeList", typeList);
			request.setAttribute("bookList", bookList);
			request.setAttribute("pages", pages);
			request.setAttribute("nowPage", nowPage);
			request.setAttribute("book", book);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		}
	}
	
}
