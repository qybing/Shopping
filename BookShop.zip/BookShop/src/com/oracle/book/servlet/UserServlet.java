package com.oracle.book.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oracle.book.biz.impl.TypeBizImpl;
import com.oracle.book.biz.impl.UserBizImpl;
import com.oracle.book.entity.Type;
import com.oracle.book.entity.User;

public class UserServlet extends HttpServlet {
	private UserBizImpl userBiz = new UserBizImpl();
	private TypeBizImpl typeBiz = new TypeBizImpl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ����ʽ
				request.setCharacterEncoding("utf-8");
		try{
		String type = request.getParameter("type");
		if("login".equals(type)){
			login(request,response);
			return;
		}
		if("register".equals(type)){
			register(request,response);
			return;
		}
		if("loginout".equals(type)){
			loginout(request,response);
			return;
		}
		}catch(Exception e){
			e.printStackTrace();
			response.sendRedirect("error.jsp");
		}
	}

	public void login(HttpServletRequest request, HttpServletResponse response) throws Exception{
	
		// ��ȡ����
		String uname = request.getParameter("uname");
		String upass = request.getParameter("upass");
		String yzm = request.getParameter("yzm");
		HttpSession session = request.getSession();
		String sys_yzm = (String)session.getAttribute("random");
		if(!sys_yzm.equals(yzm)){
			request.setAttribute("msg", "��֤�����");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		// ����ҵ��ķ���
	
		User user = userBiz.findUser(uname, upass);
	
		// ��תҳ��
		if(user==null){
			request.setAttribute("msg", "�û������������");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}else{
			List<Type> typeList =  typeBiz.findTypes();
				
			// �ж��û��Ƿ�Ҫ��ס����
			String save = request.getParameter("saveInfo");
			if("save".equals(save)){
				// ����cookie��������
				Cookie cookie1 = new Cookie("uname",URLEncoder.encode(uname, "utf-8"));
				Cookie cookie2 = new Cookie("upass",upass);
				//����cookie��ʵЧʱ��(����Ϊ��λ)
				cookie1.setMaxAge(60*2);
				cookie2.setMaxAge(60*2);
				//����response����cookie���͵��ͻ���
				response.addCookie(cookie1);
				response.addCookie(cookie2);
			}
				

			session.setAttribute("typeList", typeList);
			session.setAttribute("user", user);
			if(user.getUlevel()==0)
				response.sendRedirect("mainServlet");
			else
				response.sendRedirect("admin/admin_main.jsp");
			}
	}
	
	public void register(HttpServletRequest request, HttpServletResponse response) throws Exception{
		// ���ñ����ʽ
		// ��ȡ����Ĳ���
		String uname = request.getParameter("uname");
		String upass = request.getParameter("upass");
		String upass2 = request.getParameter("upass2");
		if(!upass.equals(upass2)){
			request.setAttribute("msg", "�����������벻һ��");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		}
		
		User user = new User();
		user.setUname(uname);
		user.setUpass(upass2);
		
		int num = userBiz.addUser(user);
		if(num==-1){
			request.setAttribute("msg", "�û������Ѵ���");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		}
		
		response.sendRedirect("login.jsp");
	}
	
	public void loginout(HttpServletRequest request, HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();
		// session�Ķ����Ǵ��ڵģ�����ɾ���˵�½���û�
		// session.removeAttribute("user");
		session.invalidate();
		response.sendRedirect("mainServlet");
	}

}
